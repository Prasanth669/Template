import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-blck-block',
  templateUrl: './blck-block.component.html',
  styleUrls: ['./blck-block.component.scss']
})
export class BlckBlockComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
