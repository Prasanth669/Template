import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-touch',
  templateUrl: './touch.component.html',
  styleUrls: ['./touch.component.scss']
})
export class TouchComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
